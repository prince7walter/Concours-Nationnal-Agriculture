create PROCEDURE AVISC1 
(
  mat IN planteur.matricule%TYPE
) AS 
BEGIN
  update planteur set id_etat=1
  where matricule=mat ;
  
END AVISC1 ;
/

