create view VISITEF as
SELECT DISTINCT
    "CANDIDAT","DATE_VISITE","HEURE_VISITE","JUGE",libelle_etat 
FROM 
    visite vs , etat et
WHERE id_culture = 1 AND vs.id_etat=et.id_etat
/

