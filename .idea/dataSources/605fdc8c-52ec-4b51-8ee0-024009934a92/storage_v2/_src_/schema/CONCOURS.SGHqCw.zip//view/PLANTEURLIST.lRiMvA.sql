create view PLANTEURLIST as
SELECT DISTINCT 
pl.matricule, pl.nom , pl.prenom , pl.daten, pt.localisation, pt.superficie, ct.libelle_type_culture pt 
FROM 
planteur pl, plantation pt, type_culture ct 
WHERE
pl.matricule=pt.matricule and pt.id_culture=ct.id_type_culture
/

