create PROCEDURE ADDUSERS (l in utilisateur.login%TYPE, n in utilisateur.nom%TYPE, e in utilisateur.email%TYPE, p in utilisateur.mdp%TYPE) AS 
BEGIN
  INSERT INTO UTILISATEUR (login,nom,email,mdp) VALUES (l,n,e,p);
  COMMIT;
END ADDUSERS;
/

