create view JUREFVIEW as
SELECT DISTINCT
    j.id_jure, nom, prenom
FROM 
    jure j
WHERE
    id_culture=1 AND id_etat=3
ORDER BY nom
/

