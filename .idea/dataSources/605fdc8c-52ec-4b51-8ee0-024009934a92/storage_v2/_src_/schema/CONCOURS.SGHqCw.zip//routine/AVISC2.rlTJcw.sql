create PROCEDURE AVISC2
(
  mat IN planteur.matricule%TYPE
) AS 
BEGIN
  update planteur set id_etat=2
  where matricule=mat ;
  
END AVISC2 ;
/

