create view JUREOVIEW as
SELECT 
    j.id_jure, nom, prenom
FROM 
    jure j
WHERE
    id_culture=2 AND id_etat=3
/

