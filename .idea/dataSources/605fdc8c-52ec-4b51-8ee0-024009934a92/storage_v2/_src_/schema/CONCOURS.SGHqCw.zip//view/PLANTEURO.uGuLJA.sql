create view PLANTEURO as
SELECT DISTINCT
    nom , prenom
FROM 
    planteur pl, plantation pt
WHERE
    id_etat=1 and pt.id_culture = 2 and pl.matricule=pt.matricule
/

