create view ALLJURE as
SELECT DISTINCT
    "ID_JURE","NOM","PRENOM","DATEN","FONCTION","NB_PART","NB_EXEP", tc.libelle_type_culture as culture
FROM 
    jure j, type_culture tc
WHERE 
    id_etat=11 AND j.id_culture=tc.id_type_culture
/

