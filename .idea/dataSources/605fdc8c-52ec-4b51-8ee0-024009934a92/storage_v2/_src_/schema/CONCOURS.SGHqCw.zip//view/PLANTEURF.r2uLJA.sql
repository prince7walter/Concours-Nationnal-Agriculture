create view PLANTEURF as
SELECT DISTINCT
    nom , prenom
FROM 
    planteur pl, plantation pt
WHERE
    id_etat=1 and pt.id_culture = 1 and pl.matricule=pt.matricule
/

