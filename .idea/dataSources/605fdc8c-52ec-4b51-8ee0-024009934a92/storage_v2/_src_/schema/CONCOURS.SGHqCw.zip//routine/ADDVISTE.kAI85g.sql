create PROCEDURE ADDVISTE 
(
  I IN visite.id_visite%type 
, N IN visite.candidat%type 
, D IN visite.date_visite%type 
, H IN visite.heure_visite%type 
, J IN visite.juge%type 
) AS 
BEGIN
  INSERT INTO VISITE 
  VALUES (I,N,D,H,J);
  COMMIT;
END ADDVISTE;
/

