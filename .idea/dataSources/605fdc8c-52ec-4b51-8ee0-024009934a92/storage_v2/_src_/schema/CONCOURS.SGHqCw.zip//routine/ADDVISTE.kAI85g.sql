create PROCEDURE ADDVISTE
(
  I IN visite.id_visite%type 
, N IN visite.candidat%type 
, D IN visite.date_visite%type 
, H IN visite.heure_visite%type 
, J IN visite.juge%type 
, C IN visite.id_culture%TYPE
, E in visite.id_etat%TYPE
) AS 
BEGIN
  INSERT INTO VISITE (id_visite, candidat,date_visite,heure_visite,juge,id_culture,id_etat)
  VALUES (I,N,D,H,J,C,E);
  COMMIT;
END ADDVISTE;
/

