create view CANDIDATFVIEW as
SELECT DISTINCT
    pl.matricule, pl.nom, pl.prenom
FROM 
    planteur pl, candidat cd, plantation pt
WHERE
    pl.matricule=cd.matricule and pl.matricule=pt.matricule and pt.id_culture=1
/

