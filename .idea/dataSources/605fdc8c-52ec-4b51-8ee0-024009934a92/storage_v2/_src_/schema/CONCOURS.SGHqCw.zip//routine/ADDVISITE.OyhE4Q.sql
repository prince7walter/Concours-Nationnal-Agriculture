create PROCEDURE ADDVISITE
( 
  N IN visite.candidat%type 
, D IN visite.date_visite%type 
, H IN visite.heure_visite%type 
, J IN visite.juge%type 
) AS 
BEGIN
  INSERT INTO VISITE ( candidat,date_visite,heure_visite,juge)
  VALUES (N,D,H,J);
  COMMIT;
END ADDVISITE;
/

