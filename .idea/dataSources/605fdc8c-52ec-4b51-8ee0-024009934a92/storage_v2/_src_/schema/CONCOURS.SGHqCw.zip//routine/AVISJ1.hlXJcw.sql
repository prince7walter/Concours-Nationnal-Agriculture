create PROCEDURE AVISJ1 
(
  id IN jure.id_jure%TYPE
) AS 
BEGIN
  UPDATE jure SET id_ETAT='3'
  WHERE id_jure=id;
END AVISJ1;
/

