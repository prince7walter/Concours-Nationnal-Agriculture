create view PLANTEURVIEW as
SELECT DISTINCT
    pl.matricule, pl.nom, pl.prenom, pl.email, pl.daten, pl.lieun, pl.nationnalite,
    pl.contact, pl.niveau, pl.photo, pt.localisation, pt.superficie, pt.tonnage, 
    pt.certificat_prop,ep.nb_emp, ep.nb_fem, ep.salaire_moy, ep.age_mini, ep.certificat_decl,
    dp.libelle_diplome, dp.num_diplome, mc.libelle_methode, pc.libelle_piece, pc.num_piece,
    ct.libelle_type_culture, tp.libelle_type_piece, td.libelle_diplome as nom_diplome
      
FROM 
planteur pl, plantation pt, type_culture ct, diplome dp, piece pc,
type_diplome td, type_piece tp, methode_culture mc, employe ep
WHERE
pt.matricule=pl.matricule and pt.id_culture=ct.id_type_culture and 
pt.id_methode=mc.id_methode and dp.matricule=pl.matricule and 
pc.id_planteur=pt.matricule and dp.id_type_diplome=td.id_type_diplome and 
pc.id_type_piece=tp.id_type_piece and ep.matricule=pl.matricule and pl.id_etat='11'
/

