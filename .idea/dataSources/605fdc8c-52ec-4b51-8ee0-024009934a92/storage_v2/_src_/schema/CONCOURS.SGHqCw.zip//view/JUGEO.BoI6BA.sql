create view JUGEO as
SELECT DISTINCT
    nom , prenom
FROM 
    jure
WHERE
    id_etat=3 and id_culture=2
/

