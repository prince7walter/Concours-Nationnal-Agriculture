create PROCEDURE ADDVISTE1
(
  I IN visite.id_visite%type 
, N IN visite.candidat%type 
, D IN visite.date_visite%type 
, H IN visite.heure_visite%type 
, J IN visite.juge%type 
) AS 
BEGIN
  INSERT INTO VISITE (id_visite, candidat,date_visite,heure_visite,juge,id_culture,id_etat)
  VALUES (I,N,D,H,J,2,5);
  COMMIT;
END ADDVISTE1;
/

