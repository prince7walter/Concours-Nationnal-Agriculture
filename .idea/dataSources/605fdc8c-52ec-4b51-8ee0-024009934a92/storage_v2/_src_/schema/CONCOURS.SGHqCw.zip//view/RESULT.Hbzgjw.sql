create view RESULT as
SELECT 
    "ID_ETAT","LIBELLE_ETAT"
FROM 
    etat
/

